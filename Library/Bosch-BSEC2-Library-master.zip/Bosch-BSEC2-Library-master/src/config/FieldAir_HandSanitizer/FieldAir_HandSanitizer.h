
#include <stdint.h>

extern const uint8_t FieldAir_HandSanitizer_config[2277];